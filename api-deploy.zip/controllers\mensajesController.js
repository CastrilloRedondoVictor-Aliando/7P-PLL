import { getConnection, sql } from '../config/database.js';

export const getMensajes = async (req, res) => {
  try {
    const { solicitudID } = req.query;
    const pool = await getConnection();
    
    let query = `
      SELECT m.*, u.nombre as usuarioNombre, u.rol
      FROM Mensajes m
      INNER JOIN Usuarios u ON m.usuarioID = u.id
    `;
    
    if (solicitudID) {
      query += ' WHERE m.solicitudID = @solicitudID';
    }
    
    query += ' ORDER BY m.createdAt ASC';
    
    const request = pool.request();
    if (solicitudID) {
      request.input('solicitudID', sql.Int, parseInt(solicitudID));
    }
    
    const result = await request.query(query);
    
    // Mapear campos
    const mensajes = result.recordset.map(m => ({
      ...m,
      contenido: m.texto,
      fechaEnvio: m.createdAt
    }));
    
    res.json(mensajes);
  } catch (error) {
    console.error('Error obteniendo mensajes:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};

export const createMensaje = async (req, res) => {
  try {
    const { solicitudID, usuarioID, texto, rol } = req.body;
    const pool = await getConnection();
    
    const result = await pool.request()
      .input('solicitudID', sql.Int, solicitudID)
      .input('usuarioID', sql.Int, usuarioID)
      .input('texto', sql.NVarChar, texto)
      .input('rol', sql.NVarChar, rol)
      .query(`
        INSERT INTO Mensajes (solicitudID, usuarioID, texto, rol)
        OUTPUT INSERTED.*
        VALUES (@solicitudID, @usuarioID, @texto, @rol)
      `);
    
    const mensaje = result.recordset[0];
    
    // Mapear campos
    const mensajeMapped = {
      ...mensaje,
      contenido: mensaje.texto,
      fechaEnvio: mensaje.createdAt
    };
    
    res.status(201).json(mensajeMapped);
  } catch (error) {
    console.error('Error creando mensaje:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};

export const markMessagesAsRead = async (req, res) => {
  try {
    const { solicitudID } = req.body;
    const pool = await getConnection();
    
    await pool.request()
      .input('solicitudID', sql.Int, parseInt(solicitudID))
      .query('UPDATE Mensajes SET leido = 1 WHERE solicitudID = @solicitudID');
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error marcando mensajes como leídos:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};
