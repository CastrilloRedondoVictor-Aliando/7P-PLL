import express from 'express';
import { getSolicitudes, createSolicitud, updateSolicitud } from '../controllers/solicitudesController.js';

const router = express.Router();

router.get('/', getSolicitudes);
router.post('/', createSolicitud);
router.put('/:id', updateSolicitud);

export default router;
