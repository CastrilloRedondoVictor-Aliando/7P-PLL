import { getConnection, sql } from '../config/database.js';

export const getDocumentos = async (req, res) => {
  try {
    const { solicitudID } = req.query;
    const pool = await getConnection();
    
    let query = 'SELECT * FROM Documentos';
    if (solicitudID) {
      query += ' WHERE solicitudID = @solicitudID';
    }
    query += ' ORDER BY createdAt DESC';
    
    const request = pool.request();
    if (solicitudID) {
      request.input('solicitudID', sql.Int, parseInt(solicitudID));
    }
    
    const result = await request.query(query);
    
    // Mapear campos
    const documentos = result.recordset.map(d => ({
      ...d,
      nombreArchivo: d.nombre,
      urlBlob: d.url,
      fechaCarga: d.createdAt
    }));
    
    res.json(documentos);
  } catch (error) {
    console.error('Error obteniendo documentos:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};

export const createDocumento = async (req, res) => {
  try {
    const { solicitudID, nombre, tipo, url } = req.body;
    const pool = await getConnection();
    
    const result = await pool.request()
      .input('solicitudID', sql.Int, solicitudID)
      .input('nombre', sql.NVarChar, nombre)
      .input('tipo', sql.NVarChar, tipo)
      .input('url', sql.NVarChar, url)
      .query(`
        INSERT INTO Documentos (solicitudID, nombre, tipo, url)
        OUTPUT INSERTED.*
        VALUES (@solicitudID, @nombre, @tipo, @url)
      `);
    
    const documento = result.recordset[0];
    
    // Mapear campos
    const documentoMapped = {
      ...documento,
      nombreArchivo: documento.nombre,
      urlBlob: documento.url,
      fechaCarga: documento.createdAt
    };
    
    res.status(201).json(documentoMapped);
  } catch (error) {
    console.error('Error creando documento:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};

export const markDocsAsViewed = async (req, res) => {
  try {
    const { solicitudID } = req.body;
    const pool = await getConnection();
    
    await pool.request()
      .input('solicitudID', sql.Int, parseInt(solicitudID))
      .query('UPDATE Documentos SET vistoPorAdmin = 1 WHERE solicitudID = @solicitudID');
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error marcando documentos como vistos:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};
