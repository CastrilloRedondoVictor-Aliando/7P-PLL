import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import solicitudesRoutes from './routes/solicitudes.js';
import documentosRoutes from './routes/documentos.js';
import mensajesRoutes from './routes/mensajes.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Configurar CORS según el entorno
const allowedOrigins = [
  'http://localhost:5173', // Desarrollo local
  'https://polite-sky-09fcdc103.4.azurestaticapps.net', // Producción
  'http://localhost:3000'
];

const corsOptions = {
  origin: function (origin, callback) {
    // Permitir requests sin origin (como Postman) en desarrollo
    if (!origin && process.env.NODE_ENV !== 'production') return callback(null, true);
    
    if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  optionsSuccessStatus: 200
};

// Middleware
app.use(cors(corsOptions));
app.use(express.json());

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/solicitudes', solicitudesRoutes);
app.use('/api/documentos', documentosRoutes);
app.use('/api/mensajes', mensajesRoutes);

// Ruta de health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'API funcionando correctamente' });
});

// Manejo de errores global
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Algo salió mal!' });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
  console.log(`📊 API disponible en http://localhost:${PORT}/api`);
});
