import { getConnection, sql } from '../config/database.js';

export const getSolicitudes = async (req, res) => {
  try {
    const { usuarioID, rol } = req.query;
    const pool = await getConnection();
    
    let query = `
      SELECT s.*, u.nombre as usuarioNombre, u.email as usuarioEmail, u.cargo
      FROM Solicitudes s
      INNER JOIN Usuarios u ON s.usuarioID = u.id
    `;
    
    if (rol === 'user' && usuarioID) {
      query += ' WHERE s.usuarioID = @usuarioID';
    }
    
    query += ' ORDER BY s.createdAt DESC';
    
    const request = pool.request();
    if (rol === 'user' && usuarioID) {
      request.input('usuarioID', sql.Int, parseInt(usuarioID));
    }
    
    const result = await request.query(query);
    
    // Mapear campos de la BD a nombres del frontend
    const solicitudes = result.recordset.map(s => ({
      ...s,
      proyecto: s.titulo,
      comentarios: s.descripcion,
      fechaCreacion: s.createdAt,
      fechaActualizacion: s.updatedAt
    }));
    
    res.json(solicitudes);
  } catch (error) {
    console.error('Error obteniendo solicitudes:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};

export const createSolicitud = async (req, res) => {
  try {
    const { titulo, descripcion, usuarioID } = req.body;
    const pool = await getConnection();
    
    // Generar número único
    const countResult = await pool.request()
      .query('SELECT COUNT(*) as count FROM Solicitudes');
    const numero = `SOL-${String(countResult.recordset[0].count + 1).padStart(4, '0')}`;
    
    const result = await pool.request()
      .input('numero', sql.NVarChar, numero)
      .input('titulo', sql.NVarChar, titulo)
      .input('descripcion', sql.NVarChar, descripcion || '')
      .input('estado', sql.NVarChar, 'Pendiente')
      .input('usuarioID', sql.Int, usuarioID)
      .query(`
        INSERT INTO Solicitudes (numero, titulo, descripcion, estado, usuarioID)
        OUTPUT INSERTED.*
        VALUES (@numero, @titulo, @descripcion, @estado, @usuarioID)
      `);
    
    const solicitud = result.recordset[0];
    
    // Mapear campos
    const solicitudMapped = {
      ...solicitud,
      proyecto: solicitud.titulo,
      comentarios: solicitud.descripcion,
      fechaCreacion: solicitud.createdAt,
      fechaActualizacion: solicitud.updatedAt
    };
    
    res.status(201).json(solicitudMapped);
  } catch (error) {
    console.error('Error creando solicitud:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};

export const updateSolicitud = async (req, res) => {
  try {
    const { id } = req.params;
    const { titulo, descripcion, estado } = req.body;
    const pool = await getConnection();
    
    const result = await pool.request()
      .input('id', sql.Int, parseInt(id))
      .input('titulo', sql.NVarChar, titulo)
      .input('descripcion', sql.NVarChar, descripcion)
      .input('estado', sql.NVarChar, estado)
      .query(`
        UPDATE Solicitudes 
        SET titulo = @titulo, descripcion = @descripcion, estado = @estado, updatedAt = GETDATE()
        OUTPUT INSERTED.*
        WHERE id = @id
      `);
    
    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Solicitud no encontrada' });
    }
    
    const solicitud = result.recordset[0];
    
    // Mapear campos
    const solicitudMapped = {
      ...solicitud,
      proyecto: solicitud.titulo,
      comentarios: solicitud.descripcion,
      fechaCreacion: solicitud.createdAt,
      fechaActualizacion: solicitud.updatedAt
    };
    
    res.json(solicitudMapped);
  } catch (error) {
    console.error('Error actualizando solicitud:', error);
    res.status(500).json({ error: 'Error en el servidor' });
  }
};
