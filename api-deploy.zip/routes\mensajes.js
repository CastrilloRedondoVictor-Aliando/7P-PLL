import express from 'express';
import { getMensajes, createMensaje, markMessagesAsRead } from '../controllers/mensajesController.js';

const router = express.Router();

router.get('/', getMensajes);
router.post('/', createMensaje);
router.post('/mark-read', markMessagesAsRead);

export default router;
