import express from 'express';
import { getDocumentos, createDocumento, markDocsAsViewed } from '../controllers/documentosController.js';

const router = express.Router();

router.get('/', getDocumentos);
router.post('/', createDocumento);
router.post('/mark-viewed', markDocsAsViewed);

export default router;
